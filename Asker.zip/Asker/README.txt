[!] THIS IS OPEN SOURCE AND FREE TO USE. READ BELOW [!]


Hello! 
Thanks for downloading my project. Asker is an Open-Source batch project for multipule uses, asker is the basic config of the program.
I plan to relase different variations of it later on, however you can download this and modify it I ask that you at lesst give me credit along with your editded versions name.
You can email me for issues at hunterjoseph8404@gmail.com (E-Mail is business only, anything unrelated will be marked as spam and deleted!)

Thanks again for checking out my project.

[!] ASKER VERSION 1.0 DIST: INFOCOL BUILD 1 [!]

[!] NOTE [!]
This DOES NOT collect any information AT ALL. It simply asks the user questions(Which they can skip) and then saving it to a .txt file.